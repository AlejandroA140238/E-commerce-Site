<?php include 'customerheader.php'; ?>

<!DOCTYPE html>
<html>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-4" >
      <div class="panel panel-default" style="max-width: 500px;
    height: 300px;">
      <div class="panel-heading">Consoles from 1970-1979</div>
      <div class="panel-body"><div class="img-responsive"><a href = "categorypage.php?id=1"><img src="../images/MagnavoxOdyssey.png" class="img-responsive" style="width:100%" alt="1970-1979"></a></div></div>
    </div>
    </div>
    <div class="col-sm-4" > <div class="panel panel-default"  style="max-width: 500px;
    height: 300px;">
      <div class="panel-heading">Consoles from 1980-1989</div>
      <div class="panel-body"><div class="img-responsive"><a href = "categorypage.php?id=2"><img src="../images/NintendoEntertainmentSystem.png" class="img-responsive" style="width:80%" alt="1980-1989"></a></div></div>
    </div> </div>
    <div class="clearfix visible-xs"></div>
    <div class="col-sm-4"><div class="panel panel-default"  style="max-width: 500px;
    height: 300px;">
      <div class="panel-heading">Consoles from 1990-1999</div>
      <div class="panel-body"><div class="img-responsive"><a href = "categorypage.php?id=3"><img src="../images/SuperNintendoEntertainmentSystem.png" class="img-responsive" style="width:100%" alt="1990-1999"></a></div></div>
    </div></div>
    <div class="col-sm-4"><div class="panel panel-default"  style="max-width: 500px;
    height: 300px;">
      <div class="panel-heading">Consoles from 2000-2009</div>
      <div class="panel-body"><div class="img-responsive"><a href = "categorypage.php?id=4"><img src="../images/Wii.png" class="img-responsive" style="width:60%" alt="2000-2009"></a></div></div>
    </div></div>
     <div class="col-sm-4"><div class="panel panel-default"  style="max-width: 500px;
    height: 300px;">
      <div class="panel-heading">Consoles from 2010 until now</div>
      <div class="panel-body"><div class="img-responsive"><a href = "categorypage.php?id=5"><img src="../images/NintendoSwitch.png" class="img-responsive" style="width:100%" alt="2010-2019"></a></div></div>
    </div></div>
  </div>
  
</div>

		
		
	</body>

</html>
