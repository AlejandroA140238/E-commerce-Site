<!DOCTYPE html>
<html>
<!--Displays admin functions.-->
<?php include 'adminheader.php'; ?>

      <h1>Select an option below: </h1><br>
      <h4>Welcome, Admin!</h4><br>
      <p><a href="createaccount.php">Create Admin Account</a></p>
      <p><a href="employeecreateaccount.php">Create Employee Account</a></p>
      <p><a href="createmanager.php">Create Manager Account</a></p>
      <p><a href="accountlist.php">View Customer List</a></p>
      <p><a href="employeelist.php">View Employee List</a></p>
      <p><a href="managerlist.php">View Manager List</a></p>
      <p><a href="adminlist.php">View Admin List</a></p>  
     
  </body>

</html>