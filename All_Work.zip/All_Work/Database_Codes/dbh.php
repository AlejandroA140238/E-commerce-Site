<?php

//connect to database using mysqli
$db = mysqli_connect("130.68.20.108", "angelesa2", "Alex140238", "angelesa_databaseproject2.0");

if(!$db) 
{
    die("Connection failed: ".mysqli_connect_error());
}
?>
