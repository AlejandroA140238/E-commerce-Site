<?php
  /*Checks the username and password when manager
  tries to login.*/
  //Starts the session
  session_start();
  //Connects to the database
  include '../dbh.php';
  global $db;
  //Receives the user input for the login from the form in the managerloginpage.php
  $user_name = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, md5($_POST['pass']));
  //Querys the manager table
  $query = mysqli_query($db, "SELECT * FROM manager WHERE manager_Username='$user_name'");
  //Checks if the table exists
  $exists = mysqli_num_rows($query);
  $table_users = "";
  $table_password = "";
  //If there are returning rows for the username
  if($exists > 0)
  {
      //Gets all of the rows from query
      while($row = mysqli_fetch_assoc($query))
      {
        /*The first username row is passed on to the $table_users,
        and continues until the query is finished*/
        $table_users = $row['manager_Username'];
        /*The first password row is passed on to the $table_password,
        and continues until the query is finished*/
        $table_password = $row['manager_Password'];
      }
      //Checks if there are any matching fields
      if(($user_name == $table_users) && ($password == $table_password))
      {
        //If the password matches
        if($password == $table_password)
        {
          $_SESSION['user_name'] = $user_name;
        }
      }
      //If the password does not match username
      else
      {
        print '<script>alert("Incorrect Password!");</script>';
        //Redirects to the managerloginpage.php
        print '<script>window.location.assign("managerloginpage.php");</script>';
      }
  }
  //If the table and/or username does not exist in the table
  else
  {
    print '<script>alert("Incorrect Username!");</script>';
    //Redirects to the managerlogin.php
    print '<script>window.location.assign("managerlogin.php");</script>';
  }
?>

<!DOCTYPE html>
<html>
<!--Displays a page when the login is successful-->
<?php include 'managerheader.php'; ?>
<body>

      <h1>Manager Login Confirmation </h1><br>
      <h4>Welcome, <?php echo $_SESSION['user_name']; ?>!</h4><br>

      
  </body>

</html>