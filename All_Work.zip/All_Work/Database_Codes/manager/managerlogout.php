<?php
	session_start();
        unset($_SESSION['user_name']);
        session_destroy();
	header("Location: managerloginpage.php");
	//Logout is added to header, so the user can logout of website
?>