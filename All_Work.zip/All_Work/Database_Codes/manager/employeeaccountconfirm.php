<?php

  /*When the manager creates an employee account, it
    checks if the username is not already created.
     If not, it creates the employee account.*/

  //Connects to the database
  include '../dbh.php';
  global $db;

  //Receives the user input from the form 
  if($_SERVER["REQUEST_METHOD"] == "POST")
  {
    $first_name = mysqli_real_escape_string($db, $_POST['firstname']);
    $last_name = mysqli_real_escape_string($db, $_POST['lastname']);
    $phone = mysqli_real_escape_string($db, $_POST['phone']);
    $address = mysqli_real_escape_string($db, $_POST['address']);
    $dob = mysqli_real_escape_string($db, $_POST['dob']);
    $user_name = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['pass']);
    $ssn = mysqli_real_escape_string($db, $_POST['ssn']);
    $bool = true;

    //Querys the employee table
    $query = mysqli_query($db, "SELECT * FROM employee");

    //Displays all of the rows from the query
    while($row = mysqli_fetch_array($query))
    {
      /*The first username row is passed on to $table_username,
      and continues until the query is finished*/
      $table_username = $row['e_Username'];

      //Checks if there are any matching fields
      if($user_name == $table_username)
      {
        $bool = false;
        //Lets the user know if the username has been taken
        print '<script>alert("Username has been taken!");</script>';
        //Redirects to the employeecreateaccount.php
        print '<script>window.location.assign("employeecreateaccount.php");</script>';
      }


    }

    //If there are no problems of the username
    if($bool)
    {
      //Inserts the values to table employee
      $passwordmd5 = md5($password);
      mysqli_query($db, "INSERT INTO employee (e_FName, e_LName, e_Phone, e_Address, e_DOB, e_Username, e_Password, SSN) 
        VALUES ('$first_name', '$last_name', '$phone', '$address', '$dob', '$user_name', '$passwordmd5', '$ssn')");
      //Lets the user know the registration was successful
      print '<script>alert("Successfully registered!");</script>';
    }
  }
?>

<!DOCTYPE html>
<html>
<?php include 'managerheader.php'; ?>
  <body>
  
      <h1>Employee Account Confirmation </h1><br>
      <h4>First Name:</h4>
      <?php echo $first_name; ?><br>
      <h4>Last Name:</h4>
      <?php echo $last_name; ?><br>
      <h4>Phone:</h4>
      <?php echo $phone; ?><br>
      <h4>Address:</h4>
      <?php echo $address; ?><br>
      <h4>Date of Birth:</h4>
      <?php echo $dob; ?><br>
      <h4>Username:</h4>
      <?php echo $user_name; ?><br>


  </body>

</html>