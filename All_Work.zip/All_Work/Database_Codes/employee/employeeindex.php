<!DOCTYPE html>
<html>
<!--Displays page upon successful login.-->
<?php include 'employeeheader.php'; ?>
<body>
      <p>Select an option below:</p>
      <!--Need to create this page using same code as createaccount.php-->
      <p><a href="employeecreateaccount.php">Create Employee Account</a></p>
      <p><a href="employeelist.php">View Employee List</a></p>
      
    
      <?php include '../footer.php'; ?>
  </body>

</html>