-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 15, 2017 at 04:26 AM
-- Server version: 5.6.38
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `angelesa_databaseproject2.0`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `a_ID` int(11) NOT NULL,
  `a_Email` varchar(255) NOT NULL,
  `a_FName` varchar(60) NOT NULL,
  `a_LName` varchar(60) NOT NULL,
  `a_Username` varchar(60) NOT NULL,
  `a_Password` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`a_ID`, `a_Email`, `a_FName`, `a_LName`, `a_Username`, `a_Password`) VALUES
(3, 'ckent@gmail.com', 'Clark', 'Kent', 'ckent', '84d961568a65073a3bcf0eb216b2a576');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_ID` int(11) NOT NULL,
  `admin_Email` varchar(255) NOT NULL,
  `admin_FName` varchar(60) NOT NULL,
  `admin_LName` varchar(60) NOT NULL,
  `admin_Username` varchar(60) NOT NULL,
  `admin_Password` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_ID`, `admin_Email`, `admin_FName`, `admin_LName`, `admin_Username`, `admin_Password`) VALUES
(2, 'stevevai@gmail.com', 'Steve', 'Vai', 'svai', '32250170a0dca92d53ec9624f336ca24');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `p_Category` int(11) NOT NULL,
  `categoryName` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`p_Category`, `categoryName`) VALUES
(1, '1970 - 1979 Consoles'),
(2, '1980 - 1989 Consoles'),
(3, '1990 - 1999 Consoles'),
(4, '2000 - 2009 Consoles'),
(5, '2010 - 2019 Consoles');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `e_ID` int(11) NOT NULL,
  `e_FName` varchar(255) NOT NULL,
  `e_LName` varchar(255) NOT NULL,
  `e_Phone` varchar(12) NOT NULL,
  `e_Address` varchar(255) NOT NULL,
  `e_DOB` date NOT NULL,
  `e_Username` varchar(60) NOT NULL,
  `e_Password` varchar(40) NOT NULL,
  `SSN` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`e_ID`, `e_FName`, `e_LName`, `e_Phone`, `e_Address`, `e_DOB`, `e_Username`, `e_Password`, `SSN`) VALUES
(5, 'Brad', 'Chad', '973-999-9999', '123 Lexington St, Passaic, NJ, 07055', '1978-05-15', 'bchad', 'b71ed444817c6946a2df69d3c0581e4d', '999-99-9999'),
(6, 'mike', 'hunt', '333-333-3333', '54 passaic st, passaic, nj, 07055', '1999-01-16', 'mhunt', '1a1dc91c907325c69271ddf0c944bc72', '222-22-2222'),
(7, 'Pedro', 'Martinez', '444-444-4444', '142 Henry Street, Passaic, NJ, 07055', '1972-01-28', 'pangeles', '81dc9bdb52d04dc20036dbd8313ed055', '666-66-6666');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `manager_ID` int(11) NOT NULL,
  `manager_Email` varchar(255) NOT NULL,
  `manager_FName` varchar(60) NOT NULL,
  `manager_LName` varchar(60) NOT NULL,
  `manager_Username` varchar(40) NOT NULL,
  `manager_Password` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`manager_ID`, `manager_Email`, `manager_FName`, `manager_LName`, `manager_Username`, `manager_Password`) VALUES
(3, 'vsaiyan@gmail.com', 'Vegeta', 'Saiyan', 'vsaiyan', '1a1dc91c907325c69271ddf0c944bc72');

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `item_ID` int(11) NOT NULL,
  `o_ID` int(11) NOT NULL,
  `p_ID` int(11) NOT NULL,
  `item_Bill` decimal(10,2) NOT NULL,
  `item_Quantity` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`item_ID`, `o_ID`, `p_ID`, `item_Bill`, `item_Quantity`) VALUES
(1, 1, 4, '2500.00', 1),
(2, 2, 7, '0.00', 100),
(3, 2, 30, '0.00', 10),
(4, 3, 20, '0.00', 28),
(5, 4, 2, '0.00', 1),
(6, 5, 2, '0.00', 1),
(7, 6, 14, '0.00', 1),
(8, 7, 1, '0.00', 5),
(9, 8, 1, '0.00', 5),
(10, 9, 1, '0.00', 2),
(11, 10, 9, '0.00', 1),
(12, 11, 15, '0.00', 3),
(13, 12, 11, '0.00', 3),
(14, 13, 17, '0.00', 6),
(15, 14, 26, '0.00', 2),
(16, 15, 14, '0.00', 4),
(17, 15, 8, '0.00', 1),
(18, 16, 7, '0.00', 1),
(19, 17, 20, '0.00', 5),
(20, 18, 7, '0.00', 4),
(21, 19, 8, '0.00', 5),
(22, 20, 8, '0.00', 2),
(23, 21, 27, '0.00', 4),
(24, 22, 28, '0.00', 100),
(25, 23, 7, '0.00', 1),
(26, 24, 2, '0.00', 5);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `o_ID` int(11) NOT NULL,
  `a_ID` int(11) NOT NULL,
  `o_Date` datetime NOT NULL,
  `o_Bill` decimal(10,2) NOT NULL,
  `o_Quantity` int(11) NOT NULL,
  `o_Address` varchar(255) NOT NULL,
  `o_cardNumber` char(16) NOT NULL,
  `o_cardExpires` char(7) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`o_ID`, `a_ID`, `o_Date`, `o_Bill`, `o_Quantity`, `o_Address`, `o_cardNumber`, `o_cardExpires`) VALUES
(12, 1, '2017-12-14 18:11:27', '72.00', 3, '15 Monroe Street, Passaic, NJ 07055', '9874987498749874', '12/2019'),
(2, 1, '2017-12-10 20:11:43', '34890.00', 110, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(3, 1, '2017-12-10 20:13:46', '1372.00', 28, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(4, 1, '2017-12-10 20:21:02', '49.00', 1, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(5, 1, '2017-12-10 20:29:13', '49.00', 1, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(6, 1, '2017-12-10 20:30:32', '299.00', 1, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(7, 1, '2017-12-14 17:19:00', '495.00', 5, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(8, 2, '2017-12-14 17:23:18', '495.00', 5, '50 Passaic Street, Passaic, NJ 07055', '', ''),
(9, 1, '2017-12-14 17:44:45', '198.00', 2, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(10, 1, '2017-12-14 17:50:19', '99.00', 1, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(11, 1, '2017-12-14 18:01:55', '72.00', 3, '15 Monroe Street, Passaic, NJ 07055', '7894789478947894', '11/2021'),
(13, 2, '2017-12-14 18:13:52', '144.00', 6, '50 Passaic Street, Passaic, NJ 07055', '1230123012301230', '09/2020'),
(14, 2, '2017-12-14 18:16:13', '398.00', 2, '50 Passaic Street, Passaic, NJ 07055', '1234123412341234', '11/2017'),
(15, 1, '2017-12-14 18:35:52', '1395.00', 5, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(16, 1, '2017-12-14 18:36:17', '299.00', 1, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(17, 1, '2017-12-14 18:37:00', '245.00', 5, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(18, 1, '2017-12-14 18:37:21', '1196.00', 4, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(19, 1, '2017-12-15 00:32:31', '995.00', 5, '15 Monroe Street, Passaic, NJ 07055', '', ''),
(20, 3, '2017-12-15 04:24:25', '398.00', 2, '142 Gregory Avenue, Passaic, NJ 07055', '', ''),
(21, 3, '2017-12-15 04:41:13', '796.00', 4, '142 Gregory Avenue, Passaic, NJ 07055', '', ''),
(22, 3, '2017-12-15 06:38:49', '39900.00', 100, '142 Gregory Avenue, Passaic, NJ 07055', '', ''),
(23, 3, '2017-12-15 06:43:33', '299.00', 1, '142 Gregory Avenue, Passaic, NJ 07055', '', ''),
(24, 3, '2017-12-15 08:04:57', '245.00', 5, '142 Gregory Avenue, Passaic, NJ 07055', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `p_ID` int(11) NOT NULL,
  `p_Category` int(11) NOT NULL,
  `p_Price` decimal(10,2) NOT NULL,
  `p_Name` varchar(255) NOT NULL,
  `abbrvName` varchar(60) DEFAULT NULL,
  `p_Quantity` int(11) NOT NULL,
  `p_Description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_ID`, `p_Category`, `p_Price`, `p_Name`, `abbrvName`, `p_Quantity`, `p_Description`) VALUES
(1, 1, '99.00', 'Magnavox Odyssey', 'MagnavoxOdyssey', 15, 'The Magnavox Odyssey was the very first home video game system and was created by the father of video games Ralph Baer. First released by Magnavox, on January 27, 1972. It comes with two paddles, which were used to control white blocks on the screen. It also comes with 6 game cards, which has 12 games within them.'),
(2, 1, '49.00', 'Atari Sears Tele-Games Pong System', 'AtariSearsTeleGamesPongSystem', 10, 'Atari Sears Tele-Games Pong System was released through Sears during the year 1975. This console was credited as launching video games as a mainstream product. It has two paddles attached to the system, is the first to have on screen scoring, has sound, and is powered by an ac adaptor rather than batteries.'),
(3, 1, '99.00', 'Coleco Telstar', 'ColecoTelstar', 12, 'Coleco Telstar was released during 1976. This is the first console to use the new General Instruments AY-3-8500 CPU chip and is powered by a 9 volt battery. This console has 3 built in games: Tennis, Hockey and Handball. The Coleco Telstar has two paddle controllers, which are attached to the system. The games are in black and white and there is a beeper for sound and all games have an on screen scoring. In the centre of the console, there is a settings area where the user could switch the system off and change the difficult from beginner to intermediate or pro. You also choose which game to play in this area.'),
(4, 1, '49.00', 'Fairchild Channel F', 'FairchildChannelF', 20, 'The Fairchild Channel F is a cartridge console that was released during 1976. This is the first console to have ROM cartridges, while all other consoles at the time used cartridges with dedicated circuitry. It comes with a large grip handle and a triangular shaped knob at the top which could be pushed down or pulled up. The controllers are connected  to the console itself and there is a compartment within the console to store them.'),
(5, 1, '24.00', 'The Wonder Wizard Model 7702', 'TheWonderWizardModel7702', 29, 'The Wonder Wizard Model 7702 was released during 1976. This console uses a 3-position switch to choose one of three predefined combinations of difficulties, avoiding the need to change the ball speed, ball angle and bat size separately. This console is basically a Magnavox Odyssey 300 in a different casing.'),
(6, 1, '24.00', 'Atari 2600', 'Atari2600', 23, 'The Atari 2600 was release during 1977 and is credited as moving the video games market towards programmable cartridges rather than a stand alone systems with built in games. It is regarded by many as the godfather of video games. On the left hand side of the console is the on/off switch, a switch between black and white color and a difficulty switch for the 1st player. On the right hand side there is a difficult switch for the 2nd player, a game select lever and one to reset the game. In the middle of the console is the cartridge slot.'),
(7, 2, '299.00', 'Epoch Cassette Vision', 'EpochCassetteVision', 11, 'The Epoch Cassette Vision was released during 1981. It was the first affordable games console in Japan to use programmable ROM cartridges. Instead of a controller this console has 4 knobs attached to it. Each player controlled 2 knobs each: one for horizontal movement and one for vertical. There are also two fire buttons for each player.'),
(8, 2, '199.00', 'Vectrex', 'Vectrex', 12, 'The Vectrex was released during 1982. Other consoles have to be connected with a tv, while the Vextrex is integrated with a Vector Monitor; which displays vector graphics. Vectrex games came with an overlay. The player has to place the overlay over the Vextrex monitor and change it according to the game he/she play. The console comes with a game built in called Minestorm. The controllers were ahead of their time and they are similar in dimension to the controllers which the Nintendo Entertainment System and Sega Master System would use years later. Instead of a D-pad, a joystick was attached.'),
(9, 2, '99.00', 'Coleco Vision', 'ColecoVision', 9, 'The Colceo Vision was released during 1982. The controllers are stored on the top of the machine, just like the Mattel Intellivision, however the controllers were detachable. The cartridge slot is on top with the label facing towards you, so you could easily see what game you are playing. The controllers has a 12 digit numeric keypad on the front, a basic joystick and side action buttons. '),
(10, 2, '49.00', 'Atari 5200', 'Atari5200', 4, 'Atari 5200 was released during 1982.At the top of the console was the cartridge slot and a storage area to store game cartridges. At the front, there are 4 controller ports. Atari decided to replace the 1 button joystick from the 2600. The new controllers has a 12 digit keypad on the front. The controller also has an analogue joystick and 2 buttons at either side of the controller. At the top of the controller is a start, pause and reset button; which is a first for any gaming controller.\r\n\r\n'),
(11, 2, '24.00', 'Nintendo Entertainment System', 'NintendoEntertainmentSystem', 13, 'The Nintendo Entertainment System was released during 1985 in the US. There are detachable controllers that has 6 feet long cables, which meant that users didn\'t have to sit as close to the system itself. The console features a front loading cartridge slot rather than simply connecting them at the top.'),
(12, 2, '99.00', 'Sega Master System', 'SegaMasterSystem', 32, 'Sega Master System was released during 1986 in the US. This console was also known as the Mark I. Comes with the built in game Astro Warrior.'),
(13, 3, '49.00', 'Super Nintendo Entertainment System', 'SuperNintendoEntertainmentSystem', 4, 'The Super Nintendo Entertainment System was released during 1990. The Super Nintendo Entertainment System is Nintendo\'s second home console, following the Nintendo Entertainment System. This console introduced advanced graphics and sound capabilities compared with other consoles at the time. '),
(14, 3, '299.00', 'NEC TurboDuo', 'NECTurboDuo', 10, 'TurboDuo was released during 1992 in the US. Has a built-in CD and game saving capabilities, the NEC TurboGrafx-CD/TurboDuo console lets you enjoy game time. The slim and sleek design of this NEC video game console is due to the insertion of small game cards and single controller port. The top-loading for CDs enables easy switching and changing of CDs in this NEC single-controller port console. The two controllers received with the NEC TurboGrafx-CD/TurboDuo console are very responsive and comfortable to use. This NEC single-controller port console offers excellent graphics, which gives your eyes and ears the pleasure to watch vivid details and hear crystal clear audio. The Arcade-type games installed in this NEC video game console makes playing time fun and exciting.\r\n'),
(15, 3, '24.00', 'PlayStation', 'Playstation', 33, 'PlayStation was released during 1994. PlayStation revolutionized console gaming and brought a massive library of affordable games and hardware to the public. This console is powered by a 34 MHz RISC processor that ensures faster and smoother gameplay. The 8 Mb of graphics memory in this video game system gives you an enhanced gaming experience. It also supports audio CDs.'),
(16, 3, '199.00', 'NEC PC-FX', 'PC-FX', 23, 'The PC-FX is a 32-bit games console released in Japan by NEC during 1994. It is the successor to the popular PC Engine. In addition to playing PC-FX games, the console could also play audio CDs, CD+Gs  and Kodak Photo CDs. PC owners could also play PC-FX games by purchasing a PC-FX internal PC card. Also was never released in the US.'),
(17, 3, '24.00', 'Nintendo 64', 'Nintendo64', 7, 'Nintendo 64 was released during 1996. Nintendo 64 was one of the first gaming consoles to have four controller ports. The most graphically demanding Nintendo 64 games that arrived on larger 32 or 64 MB cartridges are the most advanced and detailed of the 32-bit/64-bit generation. To maximize use of the Nintendo 64, the hardware developers had to create their own custom microcode. Nintendo 64 games running on custom microcode benefited from much higher polygon counts in tandem with more advanced lighting, animation, physics and AI routines than its 32-bit competition.'),
(18, 3, '49.00', 'Sega Dreamcast', 'SegaDreamcast', 5, 'Sega Dreamcast was released during 1998.  Custom-made video, audio, and processor technology blows away the Nintendo 64 and PlayStation and puts Dreamcast in the same league as PS2 and Xbox. In another video-game first, Dreamcast comes with a 56K modem. Use your regular Internet service provider and the separately sold keyboard to access e-mail, shopping, and the World Wide Web. This console plays audio CDs.'),
(19, 4, '49.00', 'PlayStation 2', 'Playstation2', 17, 'PlayStation 2 was released during 2000. The Sony PlayStation 2 original version console Black. System includes Analog controller. AV Cable, AC Power Cord. System is equipped with: one S400 iLink connector. Two USB connectors. DVD Player software that is compatible with the SCPH-10171. DVD remote control. System is capable of running audio CD\'s. DVD videos with the NTSC designation and and CD-ROMs that have PlayStation or PlayStation 2 logos.'),
(20, 4, '49.00', 'Nintendo Gamecube', 'NintendoGamecube', 29, 'Nintendo Gamecube was released during 2001. This consoles comes with the power cable, AV cable, and indigo controller.\r\nThe 485MHz processor makes loading & starting the games faster than ever - no more long load times. The processor creates 6 to 12 million polygons per second - no more slowdowns in the middle of the game. Has supports instructions for incredible effects that will make your games will be brighter, faster, and more dramatic.It also includes 64 sound channels - you\'ll feel like you\'re in the game, with the top-quality audio.'),
(21, 4, '49.00', 'Xbox', 'Xbox', 19, 'Xbox was released during 2001. Xbox has a front-loading disc tray and four controller ports (which can be accessorized for wireless controllers). Xbox was noted for having the internal processing power of a PC, with a 733MHz Intel processor, 64MB of RAM, and a custom Nvidia graphics board called the NV2A. It was designed for compatibility with both standard type 4:3 TVs and HD-ready sets, offering 480p, 720p, and 1080i output signals in normal and widescreen aspect ratios. The Xbox also supports 5.1 Dolby Digital surround sound, along with 256 voice channels, for an immersive gameplay experience. The built-in 8GB hard drive is ample for saving games, while Xbox memory cards are also available to share data between consoles. The 8GB hard drive also helps load times and storing cache levels from games so the system is not entirely dependent on game disc information.'),
(22, 4, '99.00', 'Xbox 360', 'Xbox360', 17, 'Xbox 360 was released during 2005. Xbox 360 redefines what games look like, sound like, feel like, and play like to engage you like never before; every Xbox 360 title supports a minimum of 720p, and up to 1080p high definition resolution or 480p standard definition resolution, in 16 - 9 widescreen, with anti-aliasing so you enjoy smooth, movie-like graphics and multi-channel surround sound; vibrant characters display depth of emotion to evoke more dramatic responses, immersing you in the experience. Xbox 360 has a detachable hard drive allows you to save your games and store television shows, movies, music, pictures, trailers, extra game levels, demos and other content available from Xbox LIVE Marketplace. It comes with a Xbox 360 Wireless Controller and has a range of up to 30 feet and a battery life of 30 hours on two AA batteries.'),
(23, 4, '99.00', 'PlayStation 3', 'Playstation3', 12, 'PlayStation 3 was released during 2006. The PlayStation 3 was the first to use the Cell Broadband Engine, which is an advanced microprocessor that lets your PS3 system work at incredibly fast speeds to give you the best possible gaming and viewing experience. In addition to the advanced processor at its heart, the PS3 has a built in High Definition Blu-ray player and enormous hard disk drive (HDD) storage. Able to use an online connection to access PlayStation Network\'s free multiplayer. Bluetooth EDR capability makes communication easy and clear when you\'re teaming up with friends. Able to stream your favorite video services like Netflix and Hulu Plus for no additional fee. '),
(24, 4, '99.00', 'Wii', 'Wii', 22, 'Wii was released during 2006. Has motion-control technology that the gamer can truly interact with the game on a personal level, rather than participating as a passive player. Has\r\nup to four Wii Remote Plus controllers can be connected at once using built-in wireless technology powered by Bluetooth\r\nThe Wii controller has a sensor on it that enables the user to select menu preferences, scroll through screens, and activate the game itself.'),
(25, 5, '199.00', 'Wii U', 'WiiU', 6, 'Wii U was released during 2012. The Wii U GamePad breaks down barriers between you and your entertainment with a 6.2\" 16:9 LCD touch screen, motion control system, front-facing camera, microphone, stereo speakers, rumble feature\r\nConsole works with most games from the original Wii console and many other Wii accessories, so you can continue to enjoy your favorite Wii features. Able to play with a Wii Remote controller, the Wii U GamePad controller or a Wii U Pro Controller. Four USB 2.0 connector slots are included.'),
(26, 5, '199.00', 'Xbox One', 'XboxOne', 9, 'Xbox One was released during 2013. The console is driven by a powerful combination of CPU, GPU and 8GB of RAM, governed by an innovative OS architecture, to deliver power, speed and agility; Only Xbox One unleashes the vast and scalable power of the cloud for your games, entertainment and apps with Xbox Live.'),
(27, 5, '199.00', 'PlayStation 4', 'PlayStation4', 20, 'Playstation 4 was released during 2013. \r\nHas a suspend mode to eliminate the load time on your saved game and allows you to immediately return to where you left off by pressing the power button. Enables the greatest game developers in the world to unlock their creativity and push the boundaries of play through a platform that is tuned specifically to their needs. Able to engage in endless personal challenges between you and your community, and share your epic moments for the world to see. Gamers can share their epic triumphs by hitting the \"SHARE button\" on the controller, scan through the last few minutes of gameplay, tag it and return to the game.'),
(28, 5, '399.00', 'PlayStation 4 Pro', 'PlayStation4Pro', 11, 'Playstation 4 Pro was released during 2016. Able to explore vivid game worlds with rich visuals heightened by PS4 Pro.\r\nHas support for faster frame rates delivers super-sharp action for select PS4 games. It is compatible with every PS4 game. Play online with other PS4 players with PlayStation Plus. Has 4K streaming and 4K auto-upscaling for video content.'),
(29, 5, '299.00', 'Nintendo Switch', 'NintendoSwitch', 34, 'Nintendo Switch was released during 2017. This console provides single and multiplayer thrills at home, the Nintendo Switch system also enables gamers to play the same title wherever, whenever and with whomever they choose. The mobility of a handheld is now added to the power of a home gaming system to enable unprecedented new video game play styles.'),
(30, 5, '499.00', 'Xbox One X', 'XboxOneX', 10, 'Xbox One X was released on during 2017. It is the world\'s most powerful console. \r\nCan experience 40% more power than any other console. The games play better on Xbox One X. Has 6 teraflops of graphical processing power and a 4K Blu-ray player provides more immersive gaming and entertainment. Able to play with the greatest community of gamers on the most advanced multiplayer network.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`a_ID`,`a_Username`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_ID`,`admin_Username`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`p_Category`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`e_ID`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`manager_ID`,`manager_Username`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`item_ID`),
  ADD KEY `o_ID` (`o_ID`),
  ADD KEY `p_ID` (`p_ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`o_ID`),
  ADD KEY `a_ID` (`a_ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`p_ID`),
  ADD KEY `p_Category` (`p_Category`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `a_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `p_Category` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `e_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `manager_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `item_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `o_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `p_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
