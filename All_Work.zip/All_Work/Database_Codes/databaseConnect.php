<?php

//Connect to database using PDO 
$dsn = 'mysql:host=130.68.20.108;dbname=angelesa_databaseproject2.0';
$username = 'angelesa2';
$password = 'Alex140238';

try 
{
    $db = new PDO($dsn, $username, $password);
} 
catch (PDOException $e) 
{
    $error_message = $e->getMessage();
    echo '<p>Not connected to database</p>';
    exit();
}

?>